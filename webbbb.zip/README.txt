BIRTHDAY WEBSITE — QUICK START

1) Extract this ZIP file.
2) Open the extracted "birthday_website" folder in VS Code.
3) Open index.html and edit:
   - [HER NAME] -> your friend's name
   - [YOUR NAME] -> your name
   - Edit the birthday letter if you want.
4) Put your photos inside the "photos" folder and name them:
   photo1.jpg, photo2.jpg, photo3.jpg, photo4.jpg, photo5.jpg, photo6.jpg
   (Use .jpg filenames, or change the matching src filename in index.html.)
5) Open app.py in VS Code and run it, or open the VS Code Terminal in this folder
   and type: py app.py
6) Open http://127.0.0.1:8000 in your browser.

The website uses Python's built-in web server, so you do NOT need to install Flask.
Keep the terminal window open while viewing the website.
This runs on your own laptop. To share it as a public website, it would need hosting.
