from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os

# Run this file to open your birthday website in the browser.
os.chdir(Path(__file__).parent)

HOST = "127.0.0.1"
PORT = 8000

print("Birthday website is running!")
print(f"Open this address in your browser: http://{HOST}:{PORT}")
print("Press Ctrl + C in this window to stop the website.")

server = ThreadingHTTPServer((HOST, PORT), SimpleHTTPRequestHandler)
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nWebsite stopped.")
    server.server_close()
